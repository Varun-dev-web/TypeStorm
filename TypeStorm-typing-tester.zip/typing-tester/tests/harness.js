/* ==========================================================================
   TypeStorm — automated verification harness (development only)
   Runs the real index.html + script.js inside jsdom, simulates keystrokes,
   and asserts the telemetry maths, guards, tier logic and timer teardown.

   Usage:  node tests/harness.js
   ========================================================================== */
"use strict";

const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

const ROOT = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const script = fs.readFileSync(path.join(ROOT, "script.js"), "utf8");

const results = [];
function check(name, condition, detail) {
  results.push({ name, ok: !!condition, detail });
  const mark = condition ? "PASS" : "FAIL";
  console.log(`  [${mark}] ${name}${detail !== undefined ? "  →  " + detail : ""}`);
}
function section(title) { console.log(`\n${title}`); }

/* ---------------------------------------------------------------- setup -- */
function boot(opts = {}) {
  const dom = new JSDOM(html, {
    url: "http://localhost/index.html" + (opts.debug === false ? "" : "?debug"),
    runScripts: "outside-only",
    pretendToBeVisual: true
  });
  const { window } = dom;

  // jsdom lacks these; the app must degrade gracefully
  window.matchMedia = window.matchMedia || ((q) => ({
    matches: false, media: q, addEventListener() {}, removeEventListener() {}
  }));
  if (opts.reduceMotion) {
    window.matchMedia = (q) => ({ matches: q.includes("reduce"), media: q, addEventListener() {}, removeEventListener() {} });
  }

  // controllable clock
  const clock = { now: 1700000000000 };
  window.Date.now = () => clock.now;

  // record every interval so leaks are detectable
  const intervals = new Map();
  let nextId = 1;
  window.setInterval = (fn, ms) => { const id = nextId++; intervals.set(id, { fn, ms }); return id; };
  window.clearInterval = (id) => { intervals.delete(id); };
  window.requestAnimationFrame = () => 1;
  window.cancelAnimationFrame = () => {};

  window.eval(script);

  // The script defers boot() to DOMContentLoaded when document.readyState is
  // still "loading"; fire it synchronously so state exists immediately.
  window.document.dispatchEvent(new window.Event("DOMContentLoaded", { bubbles: true }));

  const app = {
    window,
    doc: window.document,
    clock,
    intervals,
    dbg: window.TypeStormDebug,
    $: (id) => window.document.getElementById(id),
    liveTimers: () => intervals.size,
    advance(seconds) { clock.now += seconds * 1000; },
    fireTick() { [...intervals.values()].forEach((t) => t.fn()); },
    type(text) {
      const input = window.document.getElementById("quote-input");
      for (const ch of text) {
        if (input.value.length >= this.dbg.state.quoteLength) break;
        input.value += ch;
        input.dispatchEvent(new window.InputEvent("input", {
          bubbles: true, inputType: "insertText", data: ch
        }));
      }
    },
    backspace(n = 1) {
      const input = window.document.getElementById("quote-input");
      for (let i = 0; i < n; i++) {
        input.value = input.value.slice(0, -1);
        input.dispatchEvent(new window.InputEvent("input", { bubbles: true, inputType: "deleteContentBackward", data: null }));
      }
    },
    click(id) {
      const el = window.document.getElementById(id);
      el.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    },
    quote() { return this.dbg.state.quote; },
    metrics() { return this.dbg.metrics(); }
  };

  if (!app.dbg) throw new Error("TypeStormDebug hook missing — boot() did not run");
  return app;
}

/* ================================================================ TESTS == */
console.log("TypeStorm verification harness\n==============================");

/* 1. Boot & fixture integrity ------------------------------------------- */
section("1. Boot, quote injection and initial telemetry");
{
  const app = boot();
  const st = app.dbg.state;
  const spans = app.doc.querySelectorAll("#quote-display .char");

  check("app boots and renders one span per character", spans.length === st.quoteLength && spans.length > 0,
    `${spans.length} spans / ${st.quoteLength} chars`);
  check("exactly one active caret span", app.doc.querySelectorAll("#quote-display .char.current").length === 1);
  check("initial time reads 1:00", app.$("stat-time").textContent === "1:00", app.$("stat-time").textContent);
  check("initial WPM is 0", app.$("stat-wpm").textContent === "0", app.$("stat-wpm").textContent);
  check("initial accuracy is 100%", app.$("stat-acc").textContent === "100%", app.$("stat-acc").textContent);
  check("no timer running before the first keystroke", app.liveTimers() === 0);
  check("Easy pool quotes are lowercase with no punctuation",
    !/[A-Z]/.test(app.quote()) && !/[.,;:!?"']/.test(app.quote()), app.quote().slice(0, 42) + "…");
  check("hidden input is focusable (not display:none)", app.$("quote-input").disabled === false);
  check("input has spellcheck/autocomplete guards",
    app.$("quote-input").getAttribute("spellcheck") === "false" &&
    app.$("quote-input").getAttribute("autocomplete") === "off");
}

/* 2. First-key clock start ---------------------------------------------- */
section("2. First-key countdown start");
{
  const app = boot();
  const quote = app.quote();
  app.type(quote.slice(0, 1));
  check("clock flag flips on key #1", app.dbg.state.isTyping === true);
  check("exactly one interval registered", app.liveTimers() === 1, `${app.liveTimers()} interval(s)`);
  check("interval period is 1000ms", [...app.intervals.values()][0].ms === 1000);
  app.type(quote.slice(1, 12));
  check("still exactly one interval after more keys", app.liveTimers() === 1);
}

/* 3. Correct-run WPM maths ---------------------------------------------- */
section("3. Net WPM formula (correct run)");
{
  const app = boot();
  const quote = app.quote();
  app.type(quote.slice(0, 50));           // 50 correct characters
  app.advance(30);                        // 30s elapsed → 0.5 min
  app.fireTick();

  const m = app.metrics();
  const expected = Math.round(((50 - 0) / 5) / 0.5);   // 20 WPM
  check("timeLeft derived from absolute clock", app.dbg.state.timeLeft === 30, `timeLeft=${app.dbg.state.timeLeft}`);
  check("net WPM matches ((typed-mistakes)/5)/minutes", m.netWpm === expected, `${m.netWpm} vs expected ${expected}`);
  check("gross WPM matches (typed/5)/minutes", m.grossWpm === 20, m.grossWpm);
  check("accuracy is 100% on a clean run", m.accuracy === 100, m.accuracy + "%");
  check("clock string rendered from the tick", app.$("stat-time").textContent === "0:30", app.$("stat-time").textContent);
}

/* 4. Mistake accounting & live vs monotonic ----------------------------- */
section("4. Mistake accounting (live vs. monotonic)");
{
  const app = boot();
  const quote = app.quote();

  // 5 correct, then 3 wrong characters
  app.type(quote.slice(0, 5));
  const wrong = "zzz".split("").map((c) => (c === quote[5] ? "q" : c)).join("");
  app.type(wrong);

  check("live mistakes counted per wrong character", app.dbg.state.mistakes === 3, app.dbg.state.mistakes);
  check("keystroke denominator is monotonic", app.dbg.state.totalKeystrokes === 8, app.dbg.state.totalKeystrokes);
  check("accuracy = (keys - mistakes)/keys", app.metrics().accuracy === Math.round(((8 - 3) / 8) * 100),
    app.metrics().accuracy + "%");

  // fix all three errors with backspace + retype
  app.backspace(3);
  check("backspacing clears live mistakes", app.dbg.state.mistakes === 0, app.dbg.state.mistakes);
  app.type(quote.slice(5, 8));
  check("retyping correctly keeps mistakes at 0", app.dbg.state.mistakes === 0);
  check("corrected run still reports first-pass accuracy < 100%",
    app.metrics().accuracy < 100, app.metrics().accuracy + "% (the brief's literal version would show 100%)");
  check("first-pass accuracy == (keys - firstPassErrors)/keys",
    app.metrics().accuracy === Math.round(((11 - 3) / 11) * 100), app.metrics().accuracy + "%");
  check("live/corrected accuracy is 100% again", app.metrics().accuracyLive === 100, app.metrics().accuracyLive + "%");
  check("keystroke counter never decreased", app.dbg.state.totalKeystrokes === 11, app.dbg.state.totalKeystrokes);
}

/* 5. Guards ------------------------------------------------------------- */
section("5. Division-by-zero and clamp guards");
{
  const app = boot();
  check("no-typing accuracy displays 100%", app.$("stat-acc").textContent === "100%");
  check("no-typing WPM is 0 (no NaN/Infinity)", app.metrics().netWpm === 0 && Number.isFinite(app.metrics().netWpm));

  app.type("a");   // same millisecond as start → elapsed minutes = 0
  const m = app.metrics();
  check("WPM stays finite at t=0", Number.isFinite(m.netWpm) && m.netWpm === 0, m.netWpm);

  // inflate mistakes beyond typed characters: WPM must clamp to 0
  const st = app.dbg.state;
  st.mistakes = 999;
  check("negative WPM clamps to 0", app.metrics().netWpm === 0, app.metrics().netWpm);
  check("accuracy clamps inside 0..100", app.metrics().accuracy >= 0 && app.metrics().accuracy <= 100, app.metrics().accuracy);
}

/* 6. Length clamp & completion ------------------------------------------ */
section("6. Length clamp and completion paths");
{
  const app = boot();
  const quote = app.quote();
  app.type(quote + "EXTRA-TEXT-BEYOND-THE-END");
  check("input cannot exceed quote length", app.$("quote-input").value.length === quote.length,
    `${app.$("quote-input").value.length} / ${quote.length}`);
  check("perfect completion locks the run", app.dbg.state.isActive === false);
  check("timer torn down on completion", app.liveTimers() === 0);
  check("results modal opened", app.$("modal-backdrop").hidden === false);
  check("tier reported for a perfect run", app.$("hero-tier").textContent.includes("Flawless"),
    app.$("hero-tier").textContent);
  check("graph polyline rendered", app.doc.querySelectorAll("#wpm-graph path.line").length === 1);
  check("heatmap rendered 40 cells (37 keys + 3 spacers incl. space bar)",
    app.doc.querySelectorAll("#heatmap .key").length >= 37,
    app.doc.querySelectorAll("#heatmap .key").length);
}
{
  const app = boot();
  const quote = app.quote();
  // full length, but with an error at the end
  app.type(quote.slice(0, -1) + (quote.slice(-1) === "x" ? "y" : "x"));
  check("full length with an error does NOT finish", app.dbg.state.isActive === true);
  check("hint tells the user how to finish", app.$("hint-text").textContent.toLowerCase().includes("backspace"),
    app.$("hint-text").textContent);
  app.backspace(1);
  app.type(quote.slice(-1));
  check("fixing the last character finishes the run", app.dbg.state.isActive === false);
}

/* 7. Timeout ------------------------------------------------------------ */
section("7. Timeout teardown");
{
  const app = boot();
  app.type(app.quote().slice(0, 20));
  app.advance(60);
  app.fireTick();
  check("timeout ends the run", app.dbg.state.isActive === false);
  check("clock reads 0:00", app.$("stat-time").textContent === "0:00", app.$("stat-time").textContent);
  check("interval cleared on timeout", app.liveTimers() === 0);
  check("input disabled after the run", app.$("quote-input").disabled === true);
  check("modal visible", app.$("modal-backdrop").hidden === false);
  check("WPM computed from the frozen 60s clock",
    app.metrics().netWpm === Math.round(((20 - app.dbg.state.mistakes) / 5) / 1), app.metrics().netWpm);
}

/* 8. Background-tab drift ------------------------------------------------ */
section("8. Absolute clock survives timer throttling");
{
  const app = boot();
  app.type(app.quote().slice(0, 40));
  app.advance(25);
  app.fireTick();
  check("25s elapsed → 0:35 left", app.dbg.state.timeLeft === 35, app.dbg.state.timeLeft);

  // simulate a throttled tab: no ticks for 20 seconds, wall clock keeps moving
  app.advance(20);
  app.fireTick();   // first tick after returning
  check("single late tick self-heals the clock", app.dbg.state.timeLeft === 15, app.dbg.state.timeLeft);

  app.advance(20);
  app.fireTick();
  check("overrun clamps at 0 and ends the run",
    app.dbg.state.timeLeft === 0 && app.dbg.state.isActive === false, app.dbg.state.timeLeft);
}

/* 9. Restart spam ------------------------------------------------------- */
section("9. Restart spam cannot leak intervals");
{
  const app = boot();
  app.type(app.quote().slice(0, 10));   // starts the clock
  check("clock running before the spam", app.liveTimers() === 1, app.liveTimers());
  for (let i = 0; i < 25; i++) app.click("btn-restart");
  check("25 restarts leave zero leaked intervals", app.liveTimers() === 0, app.liveTimers());
  check("restart clears the input", app.$("quote-input").value === "");
  check("restart re-enables the input", app.$("quote-input").disabled === false);
  check("restart resets telemetry",
    app.dbg.state.totalTyped === 0 && app.dbg.state.mistakes === 0 && app.dbg.state.firstPassErrors === 0);
  app.type(app.quote().slice(0, 10));
  check("the new run still owns exactly one interval", app.liveTimers() === 1, app.liveTimers());

  // restart from inside the results modal
  app.click("btn-restart");
  app.type(app.quote());
  check("modal run finished again", app.$("modal-backdrop").hidden === false);
  app.click("btn-again");
  check("restart from modal → one interval after new run starts", app.liveTimers() === 0, app.liveTimers());
  app.type(app.quote().slice(0, 5));
  check("new run starts a single fresh clock", app.liveTimers() === 1);
  check("modal closed", app.$("modal-backdrop").hidden === true);
}

/* 10. New quote / difficulty ------------------------------------------- */
section("10. Difficulty modes and pools");
{
  const app = boot();
  const easy = app.quote();
  app.click("btn-new");
  check("New quote keeps the run active", app.dbg.state.isActive === true);
  check("New quote re-renders spans", app.doc.querySelectorAll("#quote-display .char").length === app.dbg.state.quoteLength);

  app.doc.querySelector('[data-difficulty="hard"]').dispatchEvent(new app.window.MouseEvent("click", { bubbles: true }));
  const hard = app.quote();
  check("hard mode pulls from the punctuation pool", /[.,;:!?"']/.test(hard), hard.slice(0, 46) + "…");
  check("hard chip label updates", app.$("chip-difficulty").textContent === "Hard");

  app.doc.querySelector('[data-difficulty="chaos"]').dispatchEvent(new app.window.MouseEvent("click", { bubbles: true }));
  const chaos = app.quote();
  check("chaos mode randomises case", /[A-Z]/.test(chaos) && /[a-z]/.test(chaos), chaos.slice(0, 46) + "…");
  check("difficulty switch clears any previous timer", app.liveTimers() === 0);

  check("easy pool has 10 quotes", easy.length > 40);
}

/* 11. Tier selection ---------------------------------------------------- */
section("11. Result tier selection");
{
  const app = boot();                     // one instance is enough: selectTier is pure
  const pick = (wpm, accuracy, reason) =>
    app.dbg.selectTier({ netWpm: wpm, grossWpm: wpm, accuracy, accuracyLive: accuracy }, reason || "timeout");

  const cases = [
    [12, 92, "timeout", "Snail"],
    [25, 92, "timeout", "Glacial"],
    [39, 92, "timeout", "Glacial"],
    [40, 93, "timeout", "Average Human"],
    [59, 93, "timeout", "Average Human"],
    [60, 96, "timeout", "Actually Fast"],
    [79, 96, "timeout", "Actually Fast"],
    [80, 97, "timeout", "Scary Fast"],
    [99, 97, "timeout", "Scary Fast"],
    [100, 98, "timeout", "Machine"],
    [140, 98, "timeout", "Machine"],
    [30, 99, "timeout", "Sniper"],
    [75, 80, "timeout", "Butterfingers"],
    [55, 100, "completed", "Flawless"],
    [0, 100, "timeout", "Snail"]
  ];
  cases.forEach(([wpm, acc, reason, expect]) => {
    const tier = pick(wpm, acc, reason);
    check(`WPM ${wpm} / ${acc}% / ${reason} → ${expect}`,
      tier.tier.includes(expect), tier.tier);
  });

  // every tier has copy and a GIF
  const all = app.dbg.tiers.concat(Object.values(app.dbg.overrides));
  check("every tier has a title, roast and GIF",
    all.every((t) => t.title && t.roast && t.gif && t.emoji));
  check("tiers are ordered by WPM", app.dbg.tiers.every((t, i, a) => i === 0 || t.min > a[i - 1].min));

  // integration: a real finished run renders a tier into the modal
  const run = boot();
  run.type(run.quote());
  check("finished run renders a tier badge", run.$("hero-tier").textContent.startsWith("Tier —"),
    run.$("hero-tier").textContent);
  check("finished run renders a roast line", run.$("modal-roast").textContent.length > 40,
    run.$("modal-roast").textContent.slice(0, 44) + "…");
}

/* 12. Personal best ----------------------------------------------------- */
section("12. Personal best persistence");
{
  const app = boot();
  const quote = app.quote();
  app.type(quote);
  const first = JSON.parse(app.window.localStorage.getItem("typestorm.best.v1") || "{}");
  check("first run stores a personal best", !!first.easy && typeof first.easy.wpm === "number", JSON.stringify(first.easy));
  check("PB banner shown", app.$("hero-pb").hidden === false);
}

/* 13. Reduced motion & calm mode --------------------------------------- */
section("13. Reduced-motion and calm mode");
{
  const app = boot({ reduceMotion: true });
  const quote = app.quote();
  app.type(quote);                        // finishes a run → would normally burst confetti
  app.advance(60); app.fireTick();
  check("confetti never starts under prefers-reduced-motion",
    app.$("confetti").classList.contains("is-active") === false);
  app.click("calm-toggle");
  check("calm mode toggles the body class", app.doc.body.classList.contains("calm"));
  check("calm mode persists", app.window.localStorage.getItem("typestorm.calm.v1") === "true");
  app.click("calm-toggle");
  check("calm mode can be switched off", !app.doc.body.classList.contains("calm"));
}

/* 14. Keyboard: Escape, paste blocking ---------------------------------- */
section("14. Keyboard guards and paste blocking");
{
  const app = boot();
  app.type(app.quote().slice(0, 6));
  app.doc.dispatchEvent(new app.window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  check("Escape restarts a live run", app.$("quote-input").value === "" && app.dbg.state.isTyping === false);

  const input = app.$("quote-input");
  let prevented = false;
  const pasteEvent = new app.window.Event("paste", { bubbles: true, cancelable: true });
  input.dispatchEvent(pasteEvent);
  prevented = pasteEvent.defaultPrevented;
  check("paste is blocked", prevented === true);
}

/* 15. Accessibility scaffolding ---------------------------------------- */
section("15. Accessibility scaffolding");
{
  const app = boot();
  const modal = app.$("modal");
  check("modal is a labelled dialog", modal.getAttribute("role") === "dialog" && !!modal.getAttribute("aria-labelledby"));
  check("modal starts hidden", app.$("modal-backdrop").hidden === true);
  check("decorative quote display is aria-hidden", app.$("quote-display").getAttribute("aria-hidden") === "true");
  check("input has an associated label", !!app.doc.querySelector('label[for="quote-input"]'));
  check("toast is a live region", app.$("toast").getAttribute("role") === "status");
  check("sound toggle exposes aria-pressed", app.$("sound-toggle").hasAttribute("aria-pressed"));
  check("graph has an SVG title for screen readers", !!app.doc.querySelector("#wpm-graph title"));
}

/* 15b. Sub-second finish coherence -------------------------------------- */
section("15b. Sub-second finish coherence");
{
  const app = boot();
  app.type(app.quote());                       // finishes in the same millisecond
  const m = app.metrics();
  check("a sub-second clean run still scores (no ÷0 collapse)", m.netWpm > 0 && Number.isFinite(m.netWpm), m.netWpm);
  check("scoring window floors at 1 second", m.scoringSeconds === 1, m.scoringSeconds);
  check("displayed elapsed time is still the truth", m.elapsedSeconds === 0, m.elapsedSeconds);
  check("graph's last point equals the headline WPM",
    app.$("hero-wpm").textContent === String(m.netWpm), app.$("hero-wpm").textContent + " vs " + m.netWpm);
  check("graph peak annotation is not below the headline",
    Number((app.doc.querySelector("#wpm-graph text[text-anchor='end']").textContent.match(/peak (\d+)/) || [0, 0])[1]) >= m.netWpm - 1,
    app.doc.querySelector("#wpm-graph text[text-anchor='end']").textContent);
  check("personal-best copy is coherent", app.$("pb-delta").textContent.indexOf("first run") === 0 ||
    /on your best/.test(app.$("pb-delta").textContent), app.$("pb-delta").textContent);
}

/* 16. No forbidden patterns -------------------------------------------- */
section("16. Ground-rule compliance (static checks)");
{
  const js = script;
  const css = fs.readFileSync(path.join(ROOT, "style.css"), "utf8");
  check("script.js has no external imports/CDNs", !/https?:\/\/[^\s"']+\.(js|css)/.test(js));
  check("no inline event handlers in index.html", !/\son(click|input|change|keyup|keydown)=/i.test(html));
  check("no inline style attributes in index.html", !/\sstyle=/i.test(html));
  check("no eval / new Function in script.js", !/\beval\s*\(|new\s+Function\s*\(/.test(js));
  check("no innerHTML for quote injection", !/quoteDisplay\.innerHTML/.test(js));
  check("script is loaded with defer (no module CORS issues)", /<script src="script\.js" defer>/.test(html));
  check("CSS uses the required correct colour #16a34a", css.includes("#16a34a"));
  check("CSS uses the required incorrect colour #dc2626", css.includes("#dc2626"));
  check("CSS uses the required incorrect background #fee2e2", css.includes("#fee2e2"));
  check("cards capped at 720px", css.includes("--card-max: 720px"));
  check("16px card radius present", css.includes("--r-md: 16px"));
  check("blinking caret keyframes present", css.includes("@keyframes caretBlink"));
  check("button translateY press state present", /translateY\(2px\)/.test(css));
  check("prefers-reduced-motion block present", css.includes("prefers-reduced-motion"));
  check("print stylesheet present", css.includes("@media print"));
}

/* ---------------------------------------------------------------- totals -- */
const failures = results.filter((r) => !r.ok);
console.log("\n==============================");
console.log(`Total: ${results.length} checks · ${results.length - failures.length} passed · ${failures.length} failed`);
if (failures.length) {
  console.log("\nFailures:");
  failures.forEach((f) => console.log(` - ${f.name}${f.detail !== undefined ? " (" + f.detail + ")" : ""}`));
  process.exit(1);
}
console.log("All checks passed.");
